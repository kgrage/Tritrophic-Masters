# Tasia Tritrophic
Tasia's 2019 undergrad independent project using LTER data and the bad breakup algorithm 
